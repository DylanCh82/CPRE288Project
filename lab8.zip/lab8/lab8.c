/**
 * lab8.c
 *
 * For CprE 288 lab 8
 * Modified code supplied for CprE288 Labs
 * @author Dylan Christensen, Savva Zeglin
 * @date 03/25/2020
 *
 *
 */

#include "button.h"
#include "timer.h"
#include "lcd.h"
#include "adc.h"
#include "math.h" //added 3/3
#include "ping.h"
#include "driverlib/interrupt.h"
#include "interrupt.h"
#include "cyBot_Scan.h"  // For scan sensors
#include "data.h"
#include "pwm.h"


volatile float testdist = 10.0;
char buffer1[50];
float test_distances[20];
float initial_mult=0;
double output[15];
int j = 0;
double sum = 0.0;
double average = 0.0;

int main(void) {
	timer_init(); // Must be called before lcd_init(), which uses timer functions
	lcd_init();
	pingSense_init();
	signal_sense_init();
	pwm_output_init();
	testPin_init();

	set_pwm_angle (90);

while(1){

    average = getPulse(1);
	   // output[j] = 2;
	   // output = testPingTrigger(25,3);
	    //printf("Clock_diff:=%u\n",ping_clock_cycles);



	 printf("Cycle diff)=%lf\n",average);
}
	 return 0;

}
