/**
 *@file interrupt.c
 *@brief Used for interrupt handling.Includes various functions and handlers
 *
 *
 *
 *@Dylan Christensen
 *@Feb 2020
 */

// The "???" placeholders should be the same as in your uart.c file.
// The "?????" placeholders are new in this file and must be replaced.
#include <interrupt.h>
#include <stdint.h>
#include "Timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"  // For scan sensors
#include "open_interface.h"
#include "movement.h"
#include "ping.h"

volatile char receive_buffer[]; // buffer for characters received from PuTTY
volatile int receive_index = 0; // index to keep track of characters in buffer
volatile char port = 'b';
volatile int command_flag = 0;

//these probably need moved to another file
volatile unsigned long rising_edge = 0;
volatile unsigned long falling_edge = 0;
volatile unsigned long current_time = 0;
volatile uint32_t count = 0;
volatile int update_flag = 0;
volatile int new_time_measure = 0;
volatile unsigned long clock_diff = 0;
volatile unsigned long overflow = 0;


void TIMER3B_Handler(void) {

	TIMER3_ICR_R |= 0x00000400;
	/*
	 period = (edgecount - TIMER3_TBR_R);
	 edgecount = TIMER3_TBR_R;
	 */
	current_time = TIMER3_TBR_R;
	new_time_measure =0;
	switch (update_flag) {
	case 0: // code to be executed if a;
		rising_edge = current_time;

		update_flag = 1;
		break;
	case 1: // code to be executed if b;
		falling_edge = current_time;
		clock_diff = rising_edge - falling_edge; //count down timer so we do this math

		overflow = (rising_edge < falling_edge);
		if (overflow==1){
		clock_diff = ((unsigned long) overflow << 24)
				+ (rising_edge - falling_edge);
		}
		//clock_diff = (float) clock_diff / 16000000;
		update_flag = 0;
		new_time_measure = 1;

		//  1/16MHz times the number of clock signals = seconds of pulse duration
		break;
	default: // code to be executed if n doesn't match any cases
		return;
	}
}

