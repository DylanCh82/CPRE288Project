/*
 * PWM.h

 */

#ifndef PWM_H_
#define PWM_H_



#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inc/tm4c123gh6pm.h>
#include "Timer.h"




void pwm_output_init (void);
void signal_sense_init (void);
double getPulse (int number_pulses);
unsigned long decimalToHex (unsigned long decimal_to_conver);
void set_pwm_angle (int degrees);
#endif /* PWM_H_ */
