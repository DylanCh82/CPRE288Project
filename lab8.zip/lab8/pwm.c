/**
 *@file pwm.c
 *@brief Used for outputting pwm signals
 *
 *
 *
 *@Dylan Christensen
 *@March 2020
 */

#include "timer.h"
#include "pwm.h"
#include "interrupt.h"
#include "math.h"
#include <stdio.h>
#include <stdlib.h>


void pwm_output_init(void)
{
    //need to turn on bit 1 of this register VERIFIED CORRECT
    SYSCTL_RCGCGPIO_R |= 0x02;  // 1) activate clock for Port B
    while ((SYSCTL_PRGPIO_R & 0x02) == 0)
    {
    };
//
//

    //enable alternate functions on port B pins
    //enabe the alternate function for port b pin 5 by setting bit 5
    GPIO_PORTB_AFSEL_R |= 0x20;

    //enable digital functionality on port B pins
    GPIO_PORTB_DEN_R |= 0x20;

    //think this is correct but need to check in register
    GPIO_PORTB_PCTL_R |= 0x700000;

    //turn on clock signal to the timer and wait
    SYSCTL_RCGCTIMER_R |= 0x2;
    while ((SYSCTL_PRTIMER_R & 0x02) == 0)
    {
    };

    //want to disable the clock timer while we configure
    //bit 8 should be set to 0
    //this should be ok to disable
    TIMER1_CTL_R &= ~0x100;

    //clear the timer config bits
    TIMER1_CFG_R &= 0b000;

    //select a 16-bit timer register
    TIMER1_CFG_R |= 0b100;

    //zero bits 2 and 0 in the register
    //bit2=0 sets edge count mode
    //bit0=0 sets up for periodic mode
    TIMER1_TBMR_R &= 0xFFFFFFFA;

    //need to set bits: 3,1
    //bit1=1 sets up for periodic mode
    //bit3=1 sets up PWM enable
    TIMER1_TBMR_R |= 0xA;


    //Load in values for a 20ms period
    //  20ms / 62.5ns = 320,000
    // 320,000 = 0x4E200

    //Timer Prescale load value
    TIMER1_TBPR_R = 0x04;

    //main timer register
    TIMER1_TBILR_R=0xE200;

    //*********************************************
    //attmept to put this in a function for setting angle
    //Here we are setting up for testing a 25%duty cycle
    //20ms period --> 1/4*20 = 5ms HIGH--> 15ms LOW
    //  15ms/62.5ns = 240,000(dec)
    //this will eventually need to be put in a function to do the math!
    //We want 240,000(dec) or 0x03A980

    //Prescale load value
    //load 0x03
 //   TIMER1_TBPMR_R=0x03;
    TIMER1_CTL_R |= 0x0000100;  //change to enable timer
    TIMER1_CTL_R |= 0x0000001;
    //Main register load value
    //load A980
//    TIMER1_TBMATCHR_R=0xA980;
//************************************************************
    //

}

void set_pwm_angle (int degrees){
    unsigned long input = 0;
    unsigned long lower16_bits = 0;
    unsigned long upper8_bits = 0;

    //want to disable the clock timer while we configure
    //bit 8 should be set to 0
    //this should be ok to disable
    TIMER1_CTL_R &= ~0x100;
    input = (unsigned long)(-156.666*degrees+311000);
    lower16_bits =(0x00FFFF & input);
    printf("Lower bits: %u", lower16_bits);
    upper8_bits = ((input & 0xFF0000)>>16);
    printf("Upper bits: %u", upper8_bits);
    //Prescale load value
    //load 0x03
    TIMER1_TBPMR_R=upper8_bits;

    //Main register load value
    //load A980
    TIMER1_TBMATCHR_R=lower16_bits;
    TIMER1_CTL_R |= 0x0000100;  //change to enable timer
    TIMER1_CTL_R |= 0x0000001;
}

void signal_sense_init(void)
{
    //need to turn on bit 1 of this register VERIFIED CORRECT
    SYSCTL_RCGCGPIO_R |= 0x02;  // 1) activate clock for Port B
    //VERIFIED CORRECT
    while ((SYSCTL_PRGPIO_R & 0x02) == 0)
    {
    };
//
//

    //enable alternate functions on port B pins
    //enabe the alternate function for port b pin 3 by setting bit 3 (01000)
    //VERIFIED CORRECT
    GPIO_PORTB_AFSEL_R |= 0x08;

    //enable digital functionality on port B pins
    //VERIFIED CORRECT
    GPIO_PORTB_DEN_R |= 0x08;

    //think this is correct but need to check in register
    GPIO_PORTB_PCTL_R |= 0x7000;

    //turn on clock signal to the timer
    //VERIFIED CORRECT
    SYSCTL_RCGCTIMER_R |= 0x8;
    while ((SYSCTL_PRTIMER_R & 0x08) == 0)
    {
    };
    //want to disable the clock timer while we configure
    //bit 8 should be set to 0
    //this should be ok to disable
    TIMER3_CTL_R &= 0xFFFFFEFF;

    //I think this should be a 4 to set to 16 bit
    //changed 3-21
    TIMER3_CFG_R &= 0b000;
    TIMER3_CFG_R |= 0b100;

    //zero bits 0,1,2,3,4 in the register
    //VERIFIED
    TIMER3_TBMR_R &= 0xFFFFFFE0;
    //need to set bits: 4,3=0; 2,1,0=1

    TIMER3_TBMR_R |= 0x7;
    //attempting to fix by chabnging above line to below line 4/9 DJC
   // TIMER3_TBMR_R |= 0xA;

    // I have no idea why this is here
    //TIMER3_CTL_R &= 0xDFE;

    //Set timer to use both edges as events
    TIMER3_CTL_R |= 0xC00;

    //set initial values based on Bai example
    //3-21-20 DJC
    TIMER3_TBILR_R = 0x65535;

    TIMER3_TBPR_R = 0xFF;
 //   TIMER3_TBILR_R = 0xE200;

  //  TIMER3_TBPR_R = 0x4;
    //change for timer
    //clear interrupt bit
    TIMER3_ICR_R |= 0x00000400;
    //enable interupt in mask register
    TIMER3_IMR_R |= 0x00000400;

    //NVIC setup: set priority of UART1 interrupt to 1 in bits 21-23
    NVIC_PRI9_R = (NVIC_PRI9_R & 0xFFFFFF0F) | 0x00000020;

    //NVIC setup: enable interrupt for UART1, IRQ #6, set bit 6
    NVIC_EN1_R |= 0X10;

    //tell CPU to use ISR handler for UART1 (see interrupt.h file)
    //from system header file: #define INT_UART1 22
    IntRegister(INT_TIMER3B, TIMER3B_Handler);

    //globally allow CPU to service interrupts (see interrupt.h file)
    IntMasterEnable();
    TIMER3_CTL_R |= 0x0000100;  //change to enable timer
}

double getPulse(int number_pulses)
{
    float distance[number_pulses];
    double sum = 0.0;
    double average = 0.0;
    int i = 0;

    for (i=0;i<number_pulses; i++){

        while(!new_time_measure){};
        //
        distance[i] = clock_diff;

        //sum distances for later averaging
        sum = sum + distance[i];
        //pause for ?? safety
        //timer_waitMillis(50);
    }

    //average and return the average distance to object
    average = sum /(double) number_pulses;
    return average;
}



