/*
 * PING.h

 */

#ifndef PING_H_
#define PING_H_



#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inc/tm4c123gh6pm.h>
#include "Timer.h"
extern volatile uint32_t sendtime;
extern volatile float pulsetime;
extern volatile float testdist;
extern volatile double object_dist;
extern volatile unsigned long ping_clock_cycles;
extern volatile unsigned long ping_clock_cycles;
extern volatile double ping_object_distance;


double testPingTrigger (float distanace, int number_pings);
double pingTrigger (int number_pings);
void pingSense_init (void);
void testPin_init (void);
//unsigned long adc_read (void);

#endif /* PING_H_ */
