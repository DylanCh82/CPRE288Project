///**
// * lab5_template.c
// *
// * Template file for CprE 288 Lab 5
// *
// * @author Diane Rover, 2/15/2020
// *
// */
//
//#include "Timer.h"
//#include "lcd.h"
//#include "cyBot_Scan.h"  // For scan sensors
//#include "uart.h"
//
////#include <string.h>
//// Uncomment or add any include directives that are needed
//// #include "open_interface.h"
//// #include "movement.h"
//// #include "button.h"
//
////#warning "Possible unimplemented functions"
//#define REPLACEME 0
//volatile char port = 'a';
//
//int main(void) {
//	timer_init(); // Must be called before lcd_init(), which uses timer functions
//	lcd_init();
//	uart_init();
//	// cyBOT_init_Scan();
//
//	//uart_sendChar(uart_receive());
//	//uart_sendChars_LCD();
//
//	while (1) {
//
//		// YOUR CODE HERE
//		//uart_sendChar(uart_receive());
//		uart_sendMessage(uart_receive());
//
//	}
//
//}
