#include "open_interface.h"

turn_right(oi_t*sensor_data, double degrees);
turn_left(oi_t*sensor_data, double degrees);

int baseSpeed = 50; //speed of wheels
int idiotLight = 1000; //delay for Dylan

move_forward(oi_t*sensor_data, double distance_mm) {
//debug comments
//  lcd_init();
//  lcd_printf("Inside move_forward");
    double sum = 0; // distance member in oi_t struct is type double
    double distance_traveled = 0;
    oi_setWheels(baseSpeed,baseSpeed); //move forward at full speed
    while (sum < distance_mm) {
           oi_update(sensor_data);
           sum += sensor_data -> distance; // use -> notation since pointer
           int detectLeft = sensor_data -> bumpLeft;
           int detectRight = sensor_data -> bumpRight;

           if (detectLeft || detectRight) {
               //we have detected collision and will back up 15cm
               lcd_init();
               lcd_printf("I detected some collision.");
               oi_setWheels(0,0);
               timer_waitMillis(idiotLight);
               distance_traveled = 0;
               oi_setWheels(-baseSpeed,-baseSpeed);
               lcd_init();
               lcd_printf("backing up");
               while (distance_traveled > (-1) * 150) {
                   oi_update(sensor_data);
                   distance_traveled += sensor_data -> distance;
               }
               oi_setWheels(0,0);
               distance_traveled = 0;
               timer_waitMillis(idiotLight);
               lcd_init();
               lcd_printf("Done backing up");
               timer_waitMillis(idiotLight);

               if (detectLeft) {
                   lcd_init();
                   lcd_printf("turning right");
                   timer_waitMillis(idiotLight);
                   turn_right(sensor_data, 90);
               } else {
                   lcd_init();
                   lcd_printf("turning left");
                   timer_waitMillis(idiotLight);
                   turn_left(sensor_data, 90);
               }
               oi_setWheels(0,0);
               timer_waitMillis(idiotLight);
               lcd_init();
               lcd_printf("avoiding obstacle");
               oi_setWheels(baseSpeed,baseSpeed);
               while (distance_traveled < 250) {
                   oi_update(sensor_data);
                   distance_traveled += sensor_data -> distance;
               }

               if (detectLeft) {
                                 turn_left(sensor_data, 90);
                                 oi_setWheels(baseSpeed,baseSpeed);

                             } else {
                                 turn_right(sensor_data, 90);
                                 oi_setWheels(baseSpeed,baseSpeed);

                             }
           }
          // continue;
           lcd_init();
           lcd_printf("back to moving around");
    }
    oi_setWheels(0,0); //stop
    return sensor_data -> distance;
 }


move_backward(oi_t*sensor_data, double distance_mm) {
//debug comments
//  lcd_init();
//  lcd_printf("Inside move_forward");
    double sum = 0; // distance member in oi_t struct is type double
    double distance_traveled = 0;
               oi_setWheels(-baseSpeed,-baseSpeed);
               while (distance_traveled > (-1) * distance_mm) {
                   oi_update(sensor_data);
                   distance_traveled += sensor_data -> distance;
               }
               oi_setWheels(0,0);
               distance_traveled = 0;
    oi_setWheels(0,0); //stop
    return sensor_data -> distance;
 }


turn_right(oi_t*sensor_data, double degrees) {

    double sum = 0;

    oi_setWheels(-baseSpeed, baseSpeed);
    while ((-1) * sum < degrees - 14.5) {
               oi_update(sensor_data);
               sum += sensor_data -> angle; // use -> notation since pointer
//lcd_printf("I just moved %fmms!",sensor_data -> angle);
    }

    oi_setWheels(0,0);
}

turn_left(oi_t*sensor_data, double degrees) {

    double sum = 0;

    oi_setWheels(baseSpeed, -baseSpeed);
    while (sum < degrees - 14.5) {
               oi_update(sensor_data);
               sum += sensor_data -> angle; // use -> notation since pointer
// lcd_printf("I just moved %fmms!",sensor_data -> angle);
    }

    oi_setWheels(0,0);
}
