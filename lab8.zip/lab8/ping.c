/**
 *@file ping.c
 *@brief Used for interacting with the ping sensor
 *
 *
 *MODIFIED FOR LAB 8 AND PWM GENERATION
 *@Dylan Christensen
 *@March 2020
 */

#include "timer.h"
#include "ping.h"
#include "interrupt.h"
#include "math.h"

volatile uint32_t sendtime = 0;
volatile float pulsetime = 0;
volatile double object_dist = 0.0;
volatile unsigned long ping_clock_cycles = 0;
volatile double ping_object_distance = 0.0;

/**
 * This method is used to simulate the ping sensor by initializing Pin B0 as output
 * @author Dylan Christensen
 * @param none
 * @date 03/25/2020
 */
void testPin_init(void)
{

    SYSCTL_RCGCGPIO_R |= 0x02;          // 1) activate clock for Port B
    while ((SYSCTL_PRGPIO_R & 0x02) == 0)
    {
    };
    GPIO_PORTB_DIR_R |= 0x01;           // 2) make PB1 OUTput
    GPIO_PORTB_DEN_R |= 0x01;
}

/**
 * This method is used to simulate the ping sensor by calculating a pulsetime
 * based on a test (cm) distance input, sending a user defined number of pulses,
 * and then outputting the average distance.
 * @author Dylan Christensen
 * @param simulation_distance_cm The distance which will be used to calculate pulse time
 * @param number_pings: The number of measurements to take with the ping sensor.
 * @date 03/25/2020
 */

double testPingTrigger(float simulation_distance_cm, int number_pings)
{
    double distance[number_pings];
    double sum = 0.0;
    double average = 0.0;
    int i = 0;

    for (i=0;i<number_pings; i++){
        //calculate time to send HIGH: target distance x 2 (sent and reflected)
        //times the number of seconds it takes sound to travel 1cm cm*s/cm=s
        pulsetime = (simulation_distance_cm * 2) * (.0000291545);

        //change the pulsetime from a float to a unsigned long (i.e. making it microseconds instead of seconds
        sendtime = (unsigned long) (pulsetime * pow(10, 6));

        //here is where we will set the pin to high and then low
        //send the pulse for the proper time
        GPIO_PORTB_DATA_R |= 0x1;    //turn pin high
        //CHANGED TO MILLIS
        timer_waitMillis(20);    //pause for calculated time duration
        GPIO_PORTB_DATA_R &= 0xFFFFFFFE;    //set pin low again
        while(!new_time_measure){};
        //calculate the distance to object
        //number of cycles * cycletime(62.5ns)*343m/s*100cm/m*1/2(send and echo)
        distance[i] = clock_diff * 0.0000000625;

        //sum distances for later averaging
        sum = sum + distance[i];
        //pause for ?? safety
        timer_waitMillis(50);
    }

    //average and return the average distance to object
    average = sum /(double) number_pings;
    return average;
}



double pingTrigger(int number_pings)
{
    double distance[number_pings];
    double sum = 0.0;
    double average = 0.0;
    int i = 0;

    for (i=0;i<number_pings; i++){
    //disbale alt function
    //diable timer function

    SYSCTL_RCGCGPIO_R |= 0x02;  // 1) activate clock for Port B

    while ((SYSCTL_PRGPIO_R & 0x02) == 0)
    {
    };
    SYSCTL_RCGCTIMER_R |= 0x8;
    while ((SYSCTL_PRTIMER_R & 0x08) == 0)
    {
    };
    //disable interupt in mask register
    TIMER3_IMR_R &= ~0x0400;

    TIMER3_CTL_R &= 0xFFFFFEFF;  //disable timer

    //disable alt function
    GPIO_PORTB_AFSEL_R &= 0xFFFFFFF7;
    GPIO_PORTB_DIR_R |= 0x08;      // 2) make PB3 OUTput

        GPIO_PORTB_DEN_R |= 0x08;
		GPIO_PORTB_DATA_R &= 0x7;
		timer_waitMicros(5);
		GPIO_PORTB_DATA_R |= 0x8;
		timer_waitMicros(5);
		GPIO_PORTB_DATA_R &= 0x7;
		timer_waitMicros(5);
    //enable alternate functions on port B pins
    GPIO_PORTB_AFSEL_R |= 0x08;

    //enable digital functionality on port B pins
    GPIO_PORTB_DEN_R |= 0x08;

    GPIO_PORTB_PCTL_R |= 0x7000;
    TIMER3_IMR_R |= 0x00000400; //added this line 3-27-20 to re
    //calculate the distance to object
    //number of cycles * cycletime(62.5ns)*343m/s*100cm/m*1/2(send and echo)

    while(!new_time_measure){};
    distance[i] = clock_diff * 0.001071875;

    //sum distances for later averaging
    sum = sum + distance[i];
    //pause for ?? safety
    timer_waitMillis(50);
}

//average and return the average distance to object
average = sum /(double) number_pings;
return average;
}

void pingSense_init(void)
{
    //need to turn on bit 1 of this register VERIFIED CORRECT
    SYSCTL_RCGCGPIO_R |= 0x02;  // 1) activate clock for Port B
    //VERIFIED CORRECT
    while ((SYSCTL_PRGPIO_R & 0x02) == 0)
    {
    };
//
//

    //enable alternate functions on port B pins
    //enabe the alternate function for port b pin 3 by setting bit 3 (01000)
    //VERIFIED CORRECT
    GPIO_PORTB_AFSEL_R |= 0x08;

    //enable digital functionality on port B pins
    //VERIFIED CORRECT
    GPIO_PORTB_DEN_R |= 0x08;

    //think this is correct but need to check in register
    GPIO_PORTB_PCTL_R |= 0x7000;

    //turn on clock signal to the timer
    //VERIFIED CORRECT
    SYSCTL_RCGCTIMER_R |= 0x8;
    while ((SYSCTL_PRTIMER_R & 0x08) == 0)
    {
    };
    //want to disable the clock timer while we configure
    //bit 8 should be set to 0
    //this should be ok to disable
    TIMER3_CTL_R &= 0xFFFFFEFF;

    //I think this should be a 4 to set to 16 bit
    //changed 3-21
    TIMER3_CFG_R &= 0b000;
    TIMER3_CFG_R |= 0b100;

    //zero bits 0,1,2,3,4 in the register
    //VERIFIED
    TIMER3_TBMR_R &= 0xFFFFFFE0;
    //need to set bits: 4,3=0; 2,1,0=1
    //VERIFIED
    TIMER3_TBMR_R |= 0x7;

    // I have no idea why this is here
    //TIMER3_CTL_R &= 0xDFE;

    //Set timer to use both edges as events
    TIMER3_CTL_R |= 0xC00;

    //set initial values based on Bai example
    //3-21-20 DJC
    TIMER3_TBILR_R = 0xFFFFFF;

    TIMER3_TBPR_R = 0xFF;

    //change for timer
    //clear interrupt bit
    TIMER3_ICR_R |= 0x00000400;
    //enable interupt in mask register
    TIMER3_IMR_R |= 0x00000400;

    //NVIC setup: set priority of UART1 interrupt to 1 in bits 21-23
    NVIC_PRI9_R = (NVIC_PRI9_R & 0xFFFFFF0F) | 0x00000020;

    //NVIC setup: enable interrupt for UART1, IRQ #6, set bit 6
    NVIC_EN1_R |= 0X10;

    //tell CPU to use ISR handler for UART1 (see interrupt.h file)
    //from system header file: #define INT_UART1 22
    IntRegister(INT_TIMER3B, TIMER3B_Handler);

    //globally allow CPU to service interrupts (see interrupt.h file)
    IntMasterEnable();
    TIMER3_CTL_R |= 0x0000100;	//change to enable timer
}

//unsigned long adc_read (void) {

//}

